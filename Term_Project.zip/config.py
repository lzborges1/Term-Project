import os
from dotenv import load_dotenv

load_dotenv()

MAPBOX_TOKEN = "pk.eyJ1IjoibGJvcmdlczEiLCJhIjoiY2xwZzBhNTB6MGRycDJscTlqaGJraGViZCJ9.hMLIPk3DjpqDK2F0gl0FTg" 
TRAFFIC_API_KEY = "LXGJU837T6rIksKmQQNwbl7m7GabzgpZ"
